// JavaScript Document
function mensagem(){
	window.alert("O Aplicativo está em construção");
}